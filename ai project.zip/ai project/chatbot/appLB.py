import os
import openai
import chainlit as cl
from pathlib import Path 
import shutil
import PyPDF2
import google.generativeai as genai
import PIL.Image
from llama_index.core import (
    Settings,
    StorageContext,
    VectorStoreIndex,
    SimpleDirectoryReader,
    load_index_from_storage,
    Document,
)
from llama_index.core.node_parser import SentenceSplitter
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.query_engine.retriever_query_engine import RetrieverQueryEngine
from llama_index.core.callbacks import CallbackManager
from llama_index.core.service_context import ServiceContext
from chainlit.input_widget import Select
from chainlit.input_widget import TextInput

# openai.api_key = os.environ.get("OPENAI_API_KEY")
openai.api_key = "sk-proj-uJeUNlmVxVqE7rWsGnqQT3BlbkFJqkT2rsEkV35gLyJBkBIT"
list_topics=["p", "IT2222", "IT3333", "elements"]
genai.configure(api_key='AIzaSyBLawKS571DfI7ZzRpzDy6mC892qV2tab8')

genaimodel = genai.GenerativeModel('gemini-pro-vision')
try:
    # rebuild storage context
    storage_context = StorageContext.from_defaults(persist_dir="./prompt")
    # load index
    index = load_index_from_storage(storage_context)
except:
    documents = SimpleDirectoryReader("./data").load_data(show_progress=True)
    index = VectorStoreIndex.from_documents(documents)
    index.storage_context.persist("./prompt")

current_topic=""

async def Updata_RAG_Topic(topic):
    storage_context = StorageContext.from_defaults(persist_dir="./"+topic)
    # load index
    index = load_index_from_storage(storage_context)
    Settings.llm = OpenAI(
        model="gpt-3.5-turbo", temperature=0.1, max_tokens=1024, streaming=True
    )
    Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")
    Settings.context_window = 4096
    service_context = ServiceContext.from_defaults(callback_manager=CallbackManager([cl.LlamaIndexCallbackHandler()]))
    query_engine = index.as_query_engine(streaming=True, similarity_top_k=2, service_context=service_context)
    cl.user_session.set("query_engine", query_engine)

    await cl.Message(
        author="Assistant", content="Hello! Im an AI assistant. How may I help you "+ topic +" information?"
    ).send()
def getdesc(img):
    response = genaimodel.generate_content(["what the inside this image? Provide more detail desciption", img])
    return response.text
@cl.on_chat_start
async def start():
    actions = [
        cl.Action(name="upload", value="example_value", description="Click me!")
    ]
    actions2 = [
        cl.Action(name="delete", value="example_value", description="Click me!")
    ]
    await cl.Message(content="To upload new module content:", actions=actions).send()
    await cl.Message(content="To delete module content:", actions=actions2).send()
    settings = await cl.ChatSettings(
        [
            Select(
                id="Topics",
                label="Modules Available",
                values=list_topics,
                initial_index=0,
            )
        ]
    ).send()
    value = settings["Topics"]
    global current_topic 
    current_topic = settings["Topics"]

    Settings.llm = OpenAI(
        model="gpt-3.5-turbo", temperature=0.1, max_tokens=1024, streaming=True
    )
    Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")
    Settings.context_window = 4096

    service_context = ServiceContext.from_defaults(callback_manager=CallbackManager([cl.LlamaIndexCallbackHandler()]))
    query_engine = index.as_query_engine(streaming=True, similarity_top_k=2, service_context=service_context)
    cl.user_session.set("query_engine", query_engine)

    topic = settings['Topics']

    await cl.Message(
        author="Assistant-"+topic, content="Hello! Im an AI assistant. How may I help you?"
    ).send()

@cl.on_settings_update
async def setup_agent(settings):
    print("on_settings_update", settings)
    topic = settings['Topics']
    global current_topic 
    current_topic = settings["Topics"]

    #change the RAG Topics
    storage_context = StorageContext.from_defaults(persist_dir="./"+topic)
    # load index
    index =  load_index_from_storage(storage_context)
    Settings.llm = OpenAI(
        model="gpt-3.5-turbo", temperature=0.1, max_tokens=1024, streaming=True
    )
    Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")
    Settings.context_window = 4096

    service_context = ServiceContext.from_defaults(callback_manager=CallbackManager([cl.LlamaIndexCallbackHandler()]))
    query_engine = index.as_query_engine(streaming=True, similarity_top_k=2, service_context=service_context)
    cl.user_session.set("query_engine", query_engine)

    await cl.Message(
        author="Assistant-"+topic, content="Hello! Im an AI assistant. How may I help you "+ topic +" information?"
    ).send()


@cl.on_message
async def main(message: cl.Message):
    global current_topic
    print(message.elements)
    #upload file
    if len(message.elements) >=1:
        storage_context = StorageContext.from_defaults(persist_dir="./"+current_topic)
        index1 =  load_index_from_storage(storage_context)
        print("element present") 
        documents = []
        print(message.elements)
        dirname = os.path.dirname(message.elements[0].path)
        for i in range(len(message.elements)):  
            print(f"---------------------------{i}")
            file = message.elements[i]
            filetype = os.path.splitext(file.path)[1]
            filename= Path(file.name).stem 
            print(filetype)
            print(dirname)
            print(filename)
            print(file.path)
            directory = f"./elements_{i}/data"
            if os.path.exists(directory):
                shutil.rmtree(directory)
            try:
                os.makedirs(directory)
                print(f"Directory '{directory}' created successfully")
            except OSError as e:
                print(f"Error: {e}")    
            if filetype == ".pdf":
                destination_file = directory+"/elements.pdf"
                shutil.copy2(file.path, destination_file)
                create_documents = SimpleDirectoryReader(directory).load_data(show_progress=True)
                print(type(create_documents[0]))
            elif filetype == ".png" or filetype == ".jpg":
                img = PIL.Image.open(file.path)
                response = getdesc(img)
                print(response)
                create_documents = [Document(text=response)]

            #store into vector 
            create_index = VectorStoreIndex.from_documents(create_documents)
            create_index.storage_context.persist("./elements")

            print(type(index1))
            # storage_context = StorageContext.from_defaults(persist_dir="./elements")
            # index2 =  load_index_from_storage(storage_context)
            document = SimpleDirectoryReader("./elements").load_data()
            documents.extend(document)
        shutil.rmtree(dirname, ignore_errors=True)
        for i in documents:
            index1.insert(i)
        service_context = ServiceContext.from_defaults(callback_manager=CallbackManager([cl.LlamaIndexCallbackHandler()]))
        query_engine = index1.as_query_engine(streaming=True, similarity_top_k=2, service_context=service_context)
        cl.user_session.set("query_engine", query_engine)

    query_engine = cl.user_session.get("query_engine") # type: RetrieverQueryEngine
   
    msg = cl.Message(content="", author="Assistant-"+ current_topic)

    res = await cl.make_async(query_engine.query)(message.content)

    for token in res.response_gen:
        await msg.stream_token(token)
    await msg.send()
@cl.action_callback("delete")
async def on_action(action: cl.Action):
    print("The user clicked on the delete button!")
    global current_topic
    print(current_topic)
    old_module = current_topic
    try:
        list_topics.remove(old_module)
        shutil.rmtree(f"./{current_topic}")
        current_topic = ""
    except:
        await cl.Message("no topic selected").send()
    settings = await cl.ChatSettings(
        [
            Select(
                id="Topics",
                label="Modules Available",
                values=list_topics,
                # initial_index=0,
                
            )
        ]
    ).send()

@cl.action_callback("upload")
async def on_action(action: cl.Action):
    print("The user clicked on the upload button!")
     # Wait for the user to upload a PDF file
    files = await cl.AskFileMessage(
        content="Please upload a PDF file to begin!", accept=["application/pdf"]
    ).send()

    pdf_file = files[0]

    dirname = os.path.dirname(pdf_file.path)
    
    filename= Path(pdf_file.name).stem 
    print(dirname)
    print(filename)
    print(pdf_file.path)

    #ask for the new module name, use to create dir
    res = await cl.AskUserMessage(content="What is the module name?", timeout=30).send()
    new_module = res['output']
    if res:
        await cl.Message(
            content=f"Your new module name is: {res['output']}",
        ).send()
    list_topics.append(new_module)
    settings = await cl.ChatSettings(
        [
            Select(
                id="Topics",
                label="Modules Available",
                values=list_topics,
                # initial_index=0,
                
            )
        ]
    ).send()


    #create new dir then subdir data to store the source file generationg vector database
    directory = "./"+new_module+"/data"
    try:
      os.makedirs(directory)
      print(f"Directory '{directory}' created successfully")
    except OSError as e:
      print(f"Error: {e}")

    #copy scr file to dest file
    destination_file = directory+"/"+new_module+".pdf"
    shutil.copy2(pdf_file.path, destination_file)

    #store into vector 
    create_documents = SimpleDirectoryReader(directory).load_data(show_progress=True)
    create_index = VectorStoreIndex.from_documents(create_documents)
    create_index.storage_context.persist("./"+new_module)


    shutil.rmtree(dirname, ignore_errors=True)

    # You can then process the PDF file as needed
    await cl.Message(
        content=f"`{pdf_file.name}` uploaded successfully!"
    ).send()

    content=f"`{pdf_file.name}` uploaded successfully!"

    return content
