"""my_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
import os
import tensorflow as tf
from tensorflow import keras
from controller import Robot
from controller import Keyboard
from controller import Camera
from pathlib import Path
import json
import sys
import numpy as np
from PIL import Image
import cv2
MODEL = Path("./ai_model.keras")#model path here
CRUISING_SPEED= 10.0
TURN_SPEED = CRUISING_SPEED/2.0
TIME_STEP = 64

# create the Robot instance.
robot = Robot()
left_wheel = robot.getDevice('left_wheel_hinge')
right_wheel = robot.getDevice('right_wheel_hinge')
left_wheel.setPosition(float('inf'))
right_wheel.setPosition(float('inf'))
left_wheel.setVelocity(0.0)
right_wheel.setVelocity(0.0)
camera = robot.getDevice('camera')
Camera.enable(camera,TIME_STEP)

keyboard = Keyboard()
step = 0
keyboard.enable(TIME_STEP)
print("aaaaa")
def preprocess_images(images):
    # Convert from integers to floats
    images_norm = images.astype("float32")
    # Normalize
    images_norm = images_norm / 255.0

    return images_norm
def predict(c,m):
	image = cv2.resize(get_image_rgb(c), (320,180 ))
	image = preprocess_images(image)
	images = image.reshape(1, image.shape[0], image.shape[1], image.shape[2])
	s = np.array(m(images,training=False))
	return s[0]

def get_image_rgb(camera):
	raw_image = camera.getImage()  # This function takes most of the CPU time
	image = np.frombuffer(raw_image, np.uint8).reshape(
		(camera.getHeight(), camera.getWidth(), 4))
	#image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
	image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
	return image
def command_motor(cmd):
	left_wheel.setVelocity(cmd[0])
	right_wheel.setVelocity(cmd[1])
mright = 0
mleft = 0
flag = False
step = 0
model = keras.models.load_model(MODEL)
while robot.step(TIME_STEP) != -1:
	left, right = predict(camera,model)
	left_wheel.setVelocity(max([left*3,0]))
	right_wheel.setVelocity(max([right*3,0]))
print("aaaaa")
x = input("a")