"""my_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from controller import Keyboard
from controller import Camera
from pathlib import Path
import json
import os
import sys
import numpy as np
from PIL import Image
import cv2
CRUISING_SPEED= 10.0
TURN_SPEED = CRUISING_SPEED/2.0
TIME_STEP = 64
SESSION = "2"
FOLDER = Path("../..")
DATASET_FOLDER = FOLDER / f"dataset/{SESSION}" 
if DATASET_FOLDER.exists():
	sys.exit()
IMAGE_FOLDER = DATASET_FOLDER / "images"
os.makedirs(IMAGE_FOLDER, exist_ok=True)

# create the Robot instance.
counter = {}
robot = Robot()
left_wheel = robot.getDevice('left_wheel_hinge')
right_wheel = robot.getDevice('right_wheel_hinge')
left_wheel.setPosition(float('inf'))
right_wheel.setPosition(float('inf'))
left_wheel.setVelocity(0.0)
right_wheel.setVelocity(0.0)
camera = robot.getDevice('camera')
Camera.enable(camera,TIME_STEP)

keyboard = Keyboard()
keyboard.enable(TIME_STEP)

def get_image_rgb(camera):
    raw_image = camera.getImage()  # This function takes most of the CPU time
    image = np.frombuffer(raw_image, np.uint8).reshape(
        (camera.getHeight(), camera.getWidth(), 4)
    )
    image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
    return image
def savedata(l,r,i,s,c):
	image = get_image_rgb(i)
	im = Image.fromarray(image)
	holder = str(l/5)+","+str(r/5)
	if holder in c: 
		c[holder] +=1
	else:
		c[holder] = 1
	print(s,c)
	image_path = IMAGE_FOLDER / f"image_{s}.png"
	im.save(image_path)
	command = {"left": l, "right": r, "image": str(image_path)}
	with open(DATASET_FOLDER / f"frame_{s}.json", "w") as f:
		json.dump(command, f)
	return c
def command_motor(cmd):
	left_wheel.setVelocity(cmd[0])
	right_wheel.setVelocity(cmd[1])
mright = 0
mleft = 0
flag = False
step = 0
flag3 = False
while robot.step(TIME_STEP) != -1:
	key = keyboard.getKey()
	right = mright
	left = mleft
	flag2 = False
	if(key == ord("P")):
		flag3 = True
	if(key == ord("R")):
		flag = True
	if(key == ord("Q")):
		flag = False
		flag3 = False
	if(key == ord('W')):
		flag2 = True
		mright = CRUISING_SPEED
		mleft = CRUISING_SPEED
		right = mright
		left = mleft
	elif (key == ord('S')):
		flag2 = True
		mright = -CRUISING_SPEED
		mleft = -CRUISING_SPEED
		right = mright
		left = mleft
	elif(key == ord("E")):
		mright = 0
		mleft = 0
		right = mright
		left = mleft
		flag2 = True
	if (key ==  ord('A')):
		flag2 = True
		left = mleft - TURN_SPEED
	elif (key ==  ord('D')):
		flag2 = True
		right = mright - TURN_SPEED
	# if (key ==  ord('E')):
	# 	left_wheel.setVelocity(0.0)
	# 	right_wheel.setVelocity(0.0)
	left_wheel.setVelocity(left)
	right_wheel.setVelocity(right)
	if (key == ord(" ")):
		counter = savedata(0,0,camera,step,counter)
		step+=1
	elif(flag and (flag2 or flag3)):
		counter = savedata(left,right,camera,step,counter)
		step+=1
x = input("a")